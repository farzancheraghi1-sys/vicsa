package com.avacs.clone.profile;

import com.google.firebase.firestore.DocumentSnapshot;

/** Public profile of one user, read from Firestore document users/{uid}. */
public class UserProfile {

    public String uid = "";
    public String nick = "";
    public long userId;
    public boolean verified;
    public boolean hasPhoto;
    public long albumsCount;
    public String gender = "";
    public String avatar = "";
    public String nickColor = "";
    public String city = "";
    public String country = "";
    public String recordType = "";
    public long friendsCount;
    public String familyStatus = "";
    public long siblings;

    public static UserProfile from(DocumentSnapshot d) {
        UserProfile p = new UserProfile();
        p.uid = d.getId();
        p.nick = str(d, "nick");
        p.userId = num(d, "userId");
        p.verified = Boolean.TRUE.equals(d.getBoolean("verified"));
        p.hasPhoto = Boolean.TRUE.equals(d.getBoolean("hasPhoto"));
        p.albumsCount = num(d, "albumsCount");
        p.gender = str(d, "gender");
        p.avatar = str(d, "avatar");
        p.nickColor = str(d, "nickColor");
        p.city = str(d, "city");
        p.country = str(d, "country");
        p.recordType = str(d, "recordType");
        p.friendsCount = num(d, "friendsCount");
        p.familyStatus = str(d, "familyStatus");
        p.siblings = num(d, "siblings");
        return p;
    }

    private static String str(DocumentSnapshot d, String key) {
        String s = d.getString(key);
        return s == null ? "" : s;
    }

    private static long num(DocumentSnapshot d, String key) {
        Long n = d.getLong(key);
        return n == null ? 0L : n;
    }
}
