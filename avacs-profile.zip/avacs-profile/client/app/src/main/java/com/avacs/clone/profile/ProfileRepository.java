package com.avacs.clone.profile;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Transaction;

import java.util.HashMap;
import java.util.Map;

public class ProfileRepository {

    public interface Callback<T> {
        void onResult(T value);
        void onError(Exception e);
    }

    private final FirebaseFirestore db = FirebaseFirestore.getInstance();

    /** Loads users/{uid}. */
    public void load(String uid, final Callback<UserProfile> cb) {
        db.collection("users").document(uid).get()
                .addOnSuccessListener(d -> {
                    if (d.exists()) {
                        cb.onResult(UserProfile.from(d));
                    } else {
                        cb.onError(new Exception("Profile not found"));
                    }
                })
                .addOnFailureListener(cb::onError);
    }

    /**
     * Call once right after sign-up. Creates users/{uid} with the next numeric
     * User ID (taken from counters/users) in a single transaction.
     * Result is true if a profile was created, false if it already existed.
     */
    public void createIfMissing(String uid, String nick, final Callback<Boolean> cb) {
        final DocumentReference userRef = db.collection("users").document(uid);
        final DocumentReference counterRef = db.collection("counters").document("users");
        final String cleanNick = nick == null ? "" : nick.trim();

        db.runTransaction((Transaction.Function<Boolean>) tx -> {
            DocumentSnapshot existing = tx.get(userRef);
            if (existing.exists()) {
                return false;
            }
            DocumentSnapshot counter = tx.get(counterRef);
            Long last = counter.getLong("next");
            if (last == null) {
                throw new IllegalStateException(
                        "counters/users must exist with a number field 'next'");
            }
            long newId = last + 1;
            tx.update(counterRef, "next", newId);

            Map<String, Object> data = new HashMap<>();
            data.put("nick", cleanNick);
            data.put("userId", newId);
            data.put("verified", false);
            data.put("hasPhoto", false);
            data.put("albumsCount", 0L);
            data.put("gender", "");
            data.put("avatar", "");
            data.put("nickColor", "#000000");
            data.put("city", "");
            data.put("country", "");
            data.put("recordType", "Unconfirmed");
            data.put("friendsCount", 0L);
            data.put("familyStatus", "");
            data.put("siblings", 0L);
            data.put("createdAt", FieldValue.serverTimestamp());
            tx.set(userRef, data);
            return true;
        }).addOnSuccessListener(cb::onResult).addOnFailureListener(cb::onError);
    }

    /** Only works for accounts listed in the admins collection (enforced by Firestore rules). */
    public void setVerified(String uid, boolean verified, final Callback<Boolean> cb) {
        db.collection("users").document(uid).update("verified", verified)
                .addOnSuccessListener(v -> cb.onResult(true))
                .addOnFailureListener(cb::onError);
    }
}
