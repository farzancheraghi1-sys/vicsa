package com.avacs.clone.profile;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.avacs.clone.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/**
 * Profile dialog (same layout as the original app).
 * Usage: new ProfileDialog(context, uid).show();
 */
public class ProfileDialog extends Dialog {

    public interface Listener {
        void onChangeClicked(UserProfile profile);
    }

    private static final int SEPARATOR_COLOR = 0xFFC9B98A;

    private final String targetUid;
    private final boolean isOwn;
    private final String ownEmail;
    private Listener listener;
    private UserProfile loaded;

    private LinearLayout rows;
    private ScrollView scroll;
    private TextView txtNick;
    private TextView txtStatus;
    private TextView btnChange;

    public ProfileDialog(Context context, String targetUid) {
        super(context);
        this.targetUid = targetUid;
        FirebaseUser me = FirebaseAuth.getInstance().getCurrentUser();
        this.isOwn = me != null && me.getUid().equals(targetUid);
        String email = (me != null && isOwn) ? me.getEmail() : null;
        this.ownEmail = email == null ? "" : email;
    }

    public ProfileDialog setListener(Listener listener) {
        this.listener = listener;
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_profile);

        Window w = getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        rows = findViewById(R.id.rows);
        scroll = findViewById(R.id.scroll);
        txtNick = findViewById(R.id.txtNick);
        txtStatus = findViewById(R.id.txtStatus);
        btnChange = findViewById(R.id.btnChange);

        findViewById(R.id.rowsFrame).setClipToOutline(true);
        findViewById(R.id.btnClose).setOnClickListener(v -> dismiss());

        btnChange.setVisibility(isOwn ? View.VISIBLE : View.GONE);
        btnChange.setOnClickListener(v -> {
            if (listener != null && loaded != null) {
                listener.onChangeClicked(loaded);
            }
        });

        new ProfileRepository().load(targetUid, new ProfileRepository.Callback<UserProfile>() {
            @Override
            public void onResult(UserProfile p) {
                if (isShowing()) {
                    render(p);
                }
            }

            @Override
            public void onError(Exception e) {
                if (isShowing()) {
                    txtStatus.setText("Could not load profile");
                }
            }
        });
    }

    private void render(UserProfile p) {
        loaded = p;
        txtStatus.setVisibility(View.GONE);
        txtNick.setText(p.nick);
        rows.removeAllViews();

        addRow("Password", "********", true, 0);
        addVerifyRow(p.verified, true);
        addRow("Photo", p.hasPhoto ? "Available" : "None", true, 0);
        addRow("Photoalbums", String.valueOf(p.albumsCount), true, 0);
        addRow("Gender", orDash(p.gender), false, 0);
        addRow("Avatar", p.avatar.isEmpty() ? "Not chosen" : p.avatar, false, 0);
        addRow("Nick color", orDash(p.nickColor), false, 0);
        addRow("Personal", "", true, 0);
        addRow("City", orDash(p.city), false, 0);
        addRow("Country/region", orDash(p.country), false, 0);
        addRow("Record type", orDash(p.recordType), true, R.drawable.ic_star);
        addRow("Friends count", String.valueOf(p.friendsCount), false, 0);
        addRow("Family status", orDash(p.familyStatus), false, 0);
        addRow("Brothers/Sisters", String.valueOf(p.siblings), true, 0);
        addRow("E-mail", isOwn ? orDash(ownEmail) : "Hidden", false, 0);
        addRow("User ID", String.valueOf(p.userId), false, 0);

        limitHeight();
    }

    /** Keeps the dialog inside the screen: long content scrolls. */
    private void limitHeight() {
        final int maxH = (int) (getContext().getResources().getDisplayMetrics().heightPixels * 0.62f);
        scroll.post(() -> {
            View content = scroll.getChildAt(0);
            if (content != null && content.getHeight() > maxH) {
                scroll.getLayoutParams().height = maxH;
                scroll.requestLayout();
            }
        });
    }

    private void addRow(String label, String value, boolean separator, int labelIconRes) {
        TextView l = makeCell(label, Gravity.START | Gravity.CENTER_VERTICAL, R.drawable.bg_cell_label);
        if (labelIconRes != 0) {
            l.setCompoundDrawablesWithIntrinsicBounds(labelIconRes, 0, 0, 0);
            l.setCompoundDrawablePadding(dp(4));
        }
        TextView v = makeCell(value, Gravity.CENTER, R.drawable.bg_cell_value);
        rows.addView(buildRow(l, v));
        if (separator) {
            rows.addView(separatorView());
        }
    }

    /** Verify row: the right cell shows only the blue check (empty if not verified). */
    private void addVerifyRow(boolean verified, boolean separator) {
        TextView l = makeCell("Verify", Gravity.START | Gravity.CENTER_VERTICAL, R.drawable.bg_cell_label);

        FrameLayout cell = new FrameLayout(getContext());
        cell.setBackgroundResource(R.drawable.bg_cell_value);
        cell.setMinimumHeight(dp(28));
        if (verified) {
            ImageView check = new ImageView(getContext());
            check.setImageResource(R.drawable.ic_verified);
            check.setContentDescription("Verified");
            cell.addView(check, new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        }

        rows.addView(buildRow(l, cell));
        if (separator) {
            rows.addView(separatorView());
        }
    }

    private TextView makeCell(String text, int gravity, int bgRes) {
        TextView t = new TextView(getContext());
        t.setText(text);
        t.setTextColor(Color.BLACK);
        t.setTextSize(14);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setGravity(gravity);
        t.setBackgroundResource(bgRes);
        t.setPadding(dp(6), dp(3), dp(6), dp(3));
        t.setMinHeight(dp(28));
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }

    private LinearLayout buildRow(View left, View right) {
        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        row.addView(right, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        return row;
    }

    private View separatorView() {
        View s = new View(getContext());
        s.setBackgroundColor(SEPARATOR_COLOR);
        s.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(1))));
        return s;
    }

    private static String orDash(String s) {
        return (s == null || s.isEmpty()) ? "—" : s;
    }

    private int dp(int v) {
        return Math.round(v * getContext().getResources().getDisplayMetrics().density);
    }
}
